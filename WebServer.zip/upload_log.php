<?php
// 로그 업로드 디렉토리를 설정합니다.
$logUploadDir = "upload/info/"; // 로그 파일을 위한 업로드 디렉토리 경로

// 업로드된 파일의 정보를 가져옵니다.
$logFileName = $_FILES["logToUpload"]["name"]; // 업로드된 로그 파일의 원래 이름
$logFileTmpName = $_FILES["logToUpload"]["tmp_name"]; // 업로드된 로그 파일의 임시 경로

// 파일 확장자를 체크하고 허용되는 확장자를 지정합니다.
$allowedLogExtensions = ["txt", "log", "pcap"]; // 허용되는 로그 파일 확장자들
$logFileExtension = strtolower(pathinfo($logFileName, PATHINFO_EXTENSION)); // 업로드된 파일의 확장자를 소문자로 가져옵니다.

if (in_array($logFileExtension, $allowedLogExtensions)) {
    // 새로운 파일 이름을 생성합니다.
    $newLogFileName = uniqid() . "." . $logFileExtension; // 고유 ID를 사용하여 새로운 파일 이름을 생성합니다.
    $logUploadPath = $logUploadDir . $newLogFileName; // 업로드할 경로를 설정합니다.

    // 파일을 이동시킵니다.
    if (move_uploaded_file($logFileTmpName, $logUploadPath)) { // 임시 파일을 업로드 디렉토리로 이동합니다.
        echo "로그 파일 업로드 성공: " . $newLogFileName; // 성공 메시지를 출력합니다.
    } else {
        echo "로그 파일 업로드 실패."; // 실패 메시지를 출력합니다.
    }
} else {
    echo "지원하지 않는 파일 형식입니다. txt, log, pcap 파일만 허용됩니다."; // 허용되지 않는 파일 형식의 경우 오류 메시지를 출력합니다.
}
?>
