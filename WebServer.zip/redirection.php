<?php
// 파일 경로 설정
$file = '211.250.248.117:80/Webserver/upload/zombie.py';

// 파일이 존재하는지 확인
if (file_exists($file)) {
    // HTTP 응답 헤더 설정
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.basename($file).'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    
    // 파일을 읽어서 출력 (다운로드 시작)
    readfile($file);
    exit;
} else {
    // 파일이 존재하지 않을 경우 404 에러
    header('HTTP/1.0 404 Not Found');
    echo 'File not found!';
}
?>