<?php
// 업로드 디렉토리를 설정합니다.
$uploadDir = "upload/"; // 수정된 업로드 디렉토리 경로

$maxFileSize = 5 * 1024 * 1024; // 5MB

// 업로드된 파일의 정보를 가져옵니다.
$fileName = $_FILES["fileToUpload"]["name"]; // 업로드된 파일의 원래 이름
$fileTmpName = $_FILES["fileToUpload"]["tmp_name"]; // 업로드된 파일의 임시 경로
$fileSize = $_FILES["fileToUpload"]["size"]; // 업로드된 파일의 크기

// 파일 확장자를 체크하고 허용되는 확장자를 지정합니다.
$allowedExtensions = ["jpg", "jpeg", "png", "gif"]; // 허용되는 파일 확장자들
$fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION)); // 업로드된 파일의 확장자를 소문자로 가져옵니다.

if (in_array($fileExtension, $allowedExtensions)) {
  // 파일 크기를 체크하고 원하는 크기로 제한합니다.
  if ($fileSize <= $maxFileSize) {
    // 새로운 파일 이름을 생성합니다.
    $newFileName = uniqid() . "." . $fileExtension; // 현재 시간과 무작위 문자열을 결합하여 새로운 파일 이름을 생성합니다.
    $uploadPath = $uploadDir . $newFileName; // 업로드할 경로를 설정합니다.

    // 임시 파일의 경로를 UTF-8로 변환합니다.
    $utf8TmpFileName = mb_convert_encoding($fileTmpName, 'UTF-8', 'auto'); // 파일 경로를 UTF-8로 변환합니다.

    // 파일을 이동시킵니다.
    if (move_uploaded_file($utf8TmpFileName, $uploadPath)) { // 임시 파일을 업로드 디렉토리로 이동합니다.
      echo "파일 업로드 성공: " . $newFileName; // 성공 메시지를 출력합니다.
    } else {
      echo "파일 업로드 실패."; // 실패 메시지를 출력합니다.
    }
  } else {
    echo "파일 크기가 너무 큽니다. 최대 파일 크기는 " . ($maxFileSize / (1024 * 1024)) . "MB입니다."; // 파일 크기가 제한보다 큰 경우 오류 메시지를 출력합니다.
  }
} else {
  echo "지원하지 않는 파일 형식입니다. jpg, jpeg, png, gif 파일만 허용됩니다."; // 허용되지 않는 파일 형식의 경우 오류 메시지를 출력합니다.
}
?>
